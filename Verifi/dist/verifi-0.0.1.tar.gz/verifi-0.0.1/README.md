only three functions

createCard(ccn length lower, ccn length upper) # generate a credit card

cardLuhnChecksumIsValid(ccn) # verify the card exists based on the luhn's algorithm

checkCompany(ccn) # check which company this card comes from
